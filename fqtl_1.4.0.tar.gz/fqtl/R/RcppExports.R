fqtl.mf <- function(y, x.mean = NULL, x.var = NULL, c.mean = NULL,
                    y.loc = NULL, y.loc2 = NULL, x.mean.loc = NULL,
                    cis.dist = 5e5,
                    options.mf = list(),
                    options.reg = list()) {

    n <- nrow(y)
    m <- ncol(y)

    if(is.null(x.mean)){ x.mean <- matrix(1, nrow=n, ncol=1) }
    if(is.null(x.var)){ x.var <- matrix(1, nrow=n, ncol=1) }

    stopifnot(nrow(x.mean) == n)
    stopifnot(ncol(x.var)[1] == n)

    ## dense y ~ x.mean
    if(is.null(y.loc) || is.null(x.mean.loc)){
        return(.Call('fqtl_rcpp_train_mf', y, x.mean, x.var,
                     options.mf, options.reg,
                     PACKAGE = 'fqtl'))
    }

    ## sparse y ~ x.mean
    p <- ncol(x.mean)
    stopifnot(length(x.mean.loc) == p)
    stopifnot(length(y.loc) == m)

    if(is.null(y.loc2)){
        y.loc2 <- y.loc
    } else {
        stopifnot(length(y.loc2) == m)
        y.loc2 <- pmax(y.loc, y.loc2)
    }

    cis.x.adj <- .Call('fqtl_adj', x.mean.loc, y.loc, y.loc2, cis.dist,
                       PACKAGE = 'fqtl')

    if(!requireNamespace('Matrix', quietly = TRUE)){
        print('Matrix package is missing')
        return(NULL)
    }

    if(!requireNamespace('methods', quietly = TRUE)){
        print('methods package is missing')
        return(NULL)
    }

    x.adj.mean <- Matrix::sparseMatrix(i = cis.x.adj$d1, j = cis.x.adj$d2,
                                       x = 1, dims = c(p, m))

    ## without additional c.mean
    if(is.null(c.mean)){
        return(.Call('fqtl_rcpp_train_mf_cis', y, x.mean, x.adj.mean, x.var,
                     options.mf, options.reg, PACKAGE = 'fqtl'))
    }

    ## additional (dense) c.mean
    stopifnot(nrow(c.mean) == n)
    return(.Call('fqtl_rcpp_train_mf_cis_aux',
                 y, x.mean, x.adj.mean, c.mean, x.var,
                 options.mf, options.reg, PACKAGE = 'fqtl'))
}

fqtl.regress <- function(y, x.mean, factored = FALSE, c.mean = NULL, x.var = NULL,
                         y.loc = NULL, y.loc2 = NULL, x.mean.loc = NULL, c.mean.loc = NULL,
                         cis.dist = 5e5, weight.nk = NULL,
                         options = list(vbiter=1000, tol=1e-8, gammax=100,
                             rate=0.1, decay=-0.1, pi.ub=-1, pi.lb=-4,
                             tau.lb=-10, tau.ub=-4, verbose=TRUE)) {

    n <- nrow(y)
    m <- ncol(y)

    if(is.null(c.mean)){ c.mean <- matrix(1, nrow=n, ncol=1) }
    if(is.null(x.var)){ x.var <- matrix(1, nrow=n, ncol=1) }

    stopifnot(nrow(x.mean) == n)
    stopifnot(nrow(x.var) == n)

    if(!requireNamespace('Matrix', quietly = TRUE)){
        print('Matrix package is missing')
        return(NULL)
    }

    if(!requireNamespace('methods', quietly = TRUE)){
        print('methods package is missing')
        return(NULL)
    }

    if(!is.null(weight.nk)) {
        weighted <- TRUE
        stopifnot(nrow(weight.nk) == n)
        if(any(weight.nk < 0)) {
            print('Removed negative weights!')
            weight.nk[weight.nk < 0] <- 0
        }
    } else {
        weighted <- FALSE
    }

    if(weighted) {
        return(.Call('fqtl_rcpp_train_fwreg', PACKAGE = 'fqtl', y, x.mean, c.mean, x.var, weight.nk, options))
    } else if(factored){

        if(is.null(y.loc) || is.null(c.mean.loc)){
            return(.Call('fqtl_rcpp_train_freg', PACKAGE = 'fqtl', y, x.mean, c.mean, x.var, options))
        }

        p <- dim(c.mean)[2]
        stopifnot(length(c.mean.loc) == p)
        stopifnot(length(y.loc) == m)

        if(is.null(y.loc2)){
            y.loc2 <- y.loc
        } else {
            stopifnot(length(y.loc2) == m)
            y.loc2 <- pmax(y.loc, y.loc2)
        }

        cis.adj <- .Call('fqtl_adj', PACKAGE = 'fqtl', c.mean.loc, y.loc, y.loc2, cis.dist)

        c.mean.adj <- Matrix::sparseMatrix(i = cis.adj$d1, j = cis.adj$d2, x = 1, dims = c(p, m))

        return(.Call('fqtl_rcpp_train_freg_cis', PACKAGE = 'fqtl', y, x.mean, c.mean, c.mean.adj, x.var, options))

    } else {

        if(is.null(y.loc) || is.null(x.mean.loc)){
            return(.Call('fqtl_rcpp_train_reg', PACKAGE = 'fqtl', y, x.mean, c.mean, x.var, options))
        }

        p.x <- dim(x.mean)[2]
        stopifnot(length(x.mean.loc) == p.x)
        stopifnot(length(y.loc) == m)

        if(is.null(y.loc2)){
            y.loc2 <- y.loc
        } else {
            stopifnot(length(y.loc2) == m)
            y.loc2 <- pmax(y.loc, y.loc2)
        }

        x.cis.adj <- .Call('fqtl_adj', PACKAGE = 'fqtl', x.mean.loc, y.loc, y.loc2, cis.dist)

        x.mean.adj <- Matrix::sparseMatrix(i = x.cis.adj$d1, j = x.cis.adj$d2, x = 1, dims = c(p.x, m))

        if(is.null(c.mean.loc)){
            return(.Call('fqtl_rcpp_train_reg_cis', PACKAGE = 'fqtl', y, x.mean, x.mean.adj, c.mean, x.var, options))
        }

        ## both x.mean and c.mean hsve locations
        p.c <- dim(c.mean)[2]
        stopifnot(length(c.mean.loc) == p.c)

        c.cis.adj <- .Call('fqtl_adj', PACKAGE = 'fqtl', c.mean.loc, y.loc, y.loc2, cis.dist)
        c.mean.adj <- Matrix::sparseMatrix(i = c.cis.adj$d1, j = c.cis.adj$d2, x = 1, dims = c(p.c, m))

        return(.Call('fqtl_rcpp_train_reg_cis_cis', PACKAGE = 'fqtl',
                     y, x.mean, x.mean.adj, c.mean, c.mean.adj, x.var, options))
    }
}

nb.normalize <- function(Y) {
    R <- apply(log(1 + Y), 1, mean)
    ret <- sweep(Y, 1, exp(R), `/`)
    return(ret)
}

read.plink <- function(bed.header) {

    glue <- function(...) paste(..., sep='')
    fam.file <- glue(bed.header, '.fam')
    bim.file <- glue(bed.header, '.bim')
    bed.file <- glue(bed.header, '.bed')
    stopifnot(file.exists(fam.file))
    stopifnot(file.exists(bim.file))
    stopifnot(file.exists(bed.file))

    ## 1. read .fam and .bim file
    fam <- read.table(fam.file)
    bim <- read.table(bim.file)
    n <- dim(fam)[1]
    n.snp <- dim(bim)[1]

    ## 2. read .bed
    bed <- .Call('read_plink_bed', PACKAGE = 'fqtl', bed.file, n, n.snp)

    return(list(FAM=fam, BIM=bim, BED=bed))
}
