require(fqtl)
require(Matrix)

n <- 100
m <- 50
p <- 200

theta.left <- matrix(sign(rnorm(3)), 3, 1)
theta.right <- matrix(sign(rnorm(3)), 1, 3)
theta <- theta.left %*% theta.right

X <- matrix(rnorm(n * p), n, p)
Y <- matrix(rnorm(n * m), n, m) * 0.1
Y[,1:3] <- Y[,1:3] + X[, 1:3] %*% theta

## Factored regression
opt <- list(tol=1e-8, pi.ub=-1, gammax=100, vbiter=1500, out.residual=TRUE, svd.init = TRUE, jitter = 0.1)
out <- fqtl.regress(Y, X, factored=TRUE, options = opt)
k <- dim(out$mean.left$lodds)[2]

image(Matrix(out$mean.left$theta[1:20,]))

image(Matrix(out$mean.right$theta))

## Full regression (testing sparse coeff)
out <- fqtl.regress(Y, X, factored=FALSE, y.loc=1:m, x.mean.loc=1:p, cis.dist=5, options = opt)

image(out$mean$theta[1:50,])

## Test NB regression
rho <- 1/(1 + exp(as.vector(-scale(Y))))
Y.nb <- matrix(sapply(rho, rnbinom, n = 1, size = 10), nrow = n, ncol = m)
R <- apply(log(1 + Y.nb), 2, mean)
Y.nb <- sweep(Y.nb, 2, exp(R), `/`)

opt <- list(tol=1e-8, pi.ub=-1, gammax=1e3, vbiter=1500, model = 'nb', out.residual=TRUE)
out <- fqtl.regress(Y.nb, X, factored=TRUE, options = opt)

plot(out$resid$theta[, 1], Y.nb[, 1], pch = 19, cex = .5);

plot(as.vector(out$resid$theta), as.vector(Y))

image(Matrix(out$mean.left$theta[1:20,]))
image(Matrix(out$mean.right$theta))


